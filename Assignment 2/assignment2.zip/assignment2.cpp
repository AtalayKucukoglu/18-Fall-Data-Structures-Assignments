/* @Author
 *
 * Student Name: Atalay Küçükoğlu
 * Student ID: 150170074
 * Date: 08.11.2018
 *
 * This program prints a language model for the given text
 * and calculates the probability of co-occurrence of given two characters.
 *
 */


#include <iostream>
#include <fstream>
#include <string>
#include <cctype>
#include <cstdlib>
#include "assignment2.h"

using namespace std;

/*
 * Creates the multi linked list vocab_list
 */

void vocab_list::create() {
    head = NULL;
}

/*
 * Initializes a node for character node
 *
 * @param character value of node
 */

vocab_node* vocab_list::initialize_node(char character) {
    vocab_node* Node = new vocab_node;
    Node->character = character;
    Node->next = NULL;
    Node->list = NULL;
    return Node;
}

/*
 * Initializes a sub node for co-occurrent character
 */

occur_node* vocab_list::initialize_sub_node(char occurrence) {
    occur_node* Sub_node = new occur_node;
    Sub_node->character = occurrence;
    Sub_node->occurrence = 1;
    Sub_node->next = NULL;
    return Sub_node;
}

/*
 * Adds character nodes to the linked list in alphabetical order
 *
 * @param character value of node
 */

void vocab_list::add_char(char character) {
    vocab_node *new_char = initialize_node(character);
    if (!head) {
        head = new_char;
        return;
    }

    vocab_node *traverser = head;

    if (isalpha(character)) {       // if the character is a letter, get inside
        if (character < head->character) {
            new_char->next = head;
            head = new_char;
        } else {
            while (true) {
                if (character == traverser->character) // if the same character occurs, return
                    return;
                if (traverser->next) {
                    if (character == traverser->next->character)
                        return;
                    if (character > traverser->next->character && isalpha(traverser->next->character)) {
                        traverser = traverser->next;
                    } else break;
                } else break;
            }
            new_char->next = traverser->next;
            traverser->next = new_char;
        }
    } else {     // if the character is NOT a letter, put it at the end of the list
        while (true) {
            if (character == traverser->character)
                return;
            if (traverser->next) {
                if (character == traverser->next->character)
                    return;
                if (character < traverser->next->character) {
                    traverser = traverser->next;
                } else break;
            } else break;
        }
        new_char->next = traverser->next;
        traverser->next = new_char;
    }
}

/*
 * Adds occurrence for character
 *
 * @param character value of node
 * @param sub_character value of sub node
 *
 */
void vocab_list::add_occurrence(char character, char sub_character) {
    if (!sub_character)
        return;

    vocab_node* traverser = head;
    occur_node* new_occur = initialize_sub_node(sub_character);
    while (traverser->next && traverser->character != character) // go to the character
        traverser = traverser->next;

    if (!traverser->list) {
        traverser->list = new_occur;
    } else {
        occur_node *sub_traverser = traverser->list;

        while (true) {          // go to the sub_character
            if (sub_traverser->character == sub_character) {
                sub_traverser->occurrence++;
                return;
            }
            if (sub_traverser->next) {
                sub_traverser = sub_traverser->next;
            } else
                break;
        }
        sub_traverser->next = new_occur;
    }
}

/*
 * Prints the entire language model
 */

void vocab_list::print() {
    if (!head) {
        cout << "The list is empty!" << endl;
        return;
    }
    vocab_node *traverser = head;

    while (traverser) {
        occur_node *sub_traverser = traverser->list;
        if (traverser->character == ' ')
            cout << "<SP>:" << endl;
        else
            cout << traverser->character << ":" << endl;
        while (sub_traverser) {
            if (sub_traverser->character == ' ')
                cout << "   " << "<<SP>, " << sub_traverser->occurrence << ">" << endl;
            else
                cout << "   " << "<" << sub_traverser->character << ", " << sub_traverser->occurrence << ">" << endl;

            sub_traverser = sub_traverser->next;
        }
        traverser = traverser->next;
    }
}

/*
 * Gets the total amount of occurences of given character
 *
 * @param character value of character node
 */

int vocab_list::get_occurrence(char character) {
    int occur_count = 0;

    vocab_node* traverser = head;
    while (traverser->next && traverser->character != character) // go to the character
        traverser = traverser->next;

    if (traverser->character != character)
        return 0;

    if (!traverser->list) {
        return 0;
    }  else {
        occur_node *sub_traverser = traverser->list;

        while(true) {           // go to each sub_character and add to occur_count
            occur_count += sub_traverser->occurrence;

            if (sub_traverser->next) {
                sub_traverser = sub_traverser->next;
            } else
                break;
        }
        return occur_count;         // return total amount of occurrences
    }
}

/*
 * Gets the amount of co-occurrences of given characters
 *
 * @param character first character
 * Qparam occurrence second character
 */

int vocab_list::get_union_occurrence (char character, char occurrence) {
    vocab_node* traverser = head;
    while (traverser->next && traverser->character != character) // go to the character
        traverser = traverser->next;

    if (!traverser->list) {
        return 0;
    } else {
        occur_node *sub_traverser = traverser->list;

        while (true) {
            if (sub_traverser->character == occurrence) {
                return sub_traverser->occurrence;
            }
            if (sub_traverser->next) {
                sub_traverser = sub_traverser->next;
            } else
                break;
        }
    }
    return 0;
}

/*
 * Deletes the list to give the allocated memory back
 */

void vocab_list::delete_list() {
    vocab_node* traverser = head;
    while (traverser) {
        while (traverser->list) {
            occur_node* sub_traverser = traverser->list;
            while (sub_traverser) {
                traverser->list = sub_traverser->next;
                sub_traverser->next = NULL;
                delete sub_traverser;
                sub_traverser = traverser->list;
            }
            delete traverser->list;
        }
        head = traverser->next;
        traverser->next = NULL;
        delete traverser;
        traverser = head;
    }
    delete head;
}

/*
 * Reads the data from file and calls create, add_char ad add_occurrence
 *
 * @param text_file file to be read data from
 */

void language_model::readData(const char * text_file) {
    vocabularylist = new vocab_list;
    vocabularylist->create();

    string line;

    ifstream fileptr;

    fileptr.open(text_file, fstream::in);

    if (!fileptr) {
        cout << "File cannot be opened.";
        return;
    }

    while (!fileptr.eof()) {
        getline(fileptr, line);
        for (int i = 0; line[i] != '\0'; i++) {
            line[i] = tolower(line[i]);
        }

        for (int i = 0; line[i] != '\0' && line[i] != '\n'; i++) {
            vocabularylist->add_char(line[i]);
            vocabularylist->add_occurrence(line[i], line[i+1]);
        }
    }

    fileptr.close();

}

/*
 * Calculates the probability of co-occurence of characters
 *
 * @param character first character
 * @param occurrence second character
 */

double language_model::calculateProbability(char character, char occurrence) {
    double total_occurrence = vocabularylist->get_occurrence(character);
    double union_occurrence = vocabularylist->get_union_occurrence(character, occurrence);

    if (!total_occurrence) {
        cout << "There is no character " << "'" << character << "'" << endl;
        exit(1);
    }
    if (!union_occurrence) {
        cout << "There is no occurrence for " << "'" << occurrence << "'" << " after character " << "'" << character << "'" << endl;
        exit(1);
    }

    double probability = union_occurrence / total_occurrence;

    return probability;
}

/*
 * @param argc arguement count
 * @param argv arguements
 */

int main(int argc, char** argv) {
    language_model LM;          // language model LM is declared
    LM.readData(argv[1]);       // read data from the text file
    if (argc == 2) {            // if only text file is given, print the whole language model
        LM.vocabularylist->print();
        return 0;
    }

    // calculates the probability of co-occurrence of given characters and prints it
    cout << LM.calculateProbability(argv[2][0], argv[3][0]);
    cout << " is probability of co-occurrence \"" << argv[2][0] << "\" and \"" << argv[3][0] << "\"." << endl;

    // delete allocated memory
    LM.vocabularylist->delete_list();

    return 0;
}







/*
 * turkish char
 * newline
 * last character
 *
 *  [SOLVED] <SP> issue (putting <sp> when printing " " is an option)
 *  [SOLVED] alphabetical order
 *  [SOLVED] get_occurrence doesn't work properly (goes to the last character and returns its occur count)
 *  [SOLVED] add special chars to the back (add_char doesn't do this properly)
 */

