//
// Created by laltin on 30.10.2018.
//

#ifndef ASSIGNMENT2_ASSIGNMENT2_H
#define ASSIGNMENT2_ASSIGNMENT2_H

#endif //ASSIGNMENT2_ASSIGNMENT2_H

struct occur_node {
    char character;
    occur_node *next;
    int occurrence;
};

struct vocab_node {
    char character;
    vocab_node *next;
    occur_node *list;
};

struct vocab_list {
    vocab_node *head;
    void create();
    vocab_node* initialize_node (char );
    occur_node* initialize_sub_node (char );
    void print();
    void add_char(char );
    void add_occurrence(char , char );
    int get_occurrence(char );
    int get_union_occurrence (char , char );
    void delete_list();
};
struct language_model {
    vocab_list *vocabularylist;
    void readData(const char *);
    double calculateProbability(char, char);
};